/**
 * FLOOD MONITORING SYSTEM
 * Simple application to monitor water levels and show flood alerts
 */

import { useState } from "react";
import { WaterLevelCard } from "./components/WaterLevelCard";
import { AlertCard } from "./components/AlertCard";
import { StatsCard } from "./components/StatsCard";
import { Button } from "./components/ui/button";

export default function App() {
  // State to show/hide alerts section (Interactive Feature #1)
  const [showAlerts, setShowAlerts] = useState(true);

  // ============================================
  // DATA - Easy to modify and understand
  // ============================================

  // Statistics data - shows summary information
  const stats = [
    { label: "Total Locations", value: "3", icon: "📍" },
    { label: "Active Alerts", value: "2", icon: "⚠️" },
    { label: "Safe Areas", value: "1", icon: "✅" },
  ];

  // Water level data - one object per location
  const waterLevels = [
    {
      locationName: "North River",
      currentLevel: 4.2,
      maxLevel: 6.0,
      status: "Warning",
    },
    {
      locationName: "Central Dam",
      currentLevel: 8.5,
      maxLevel: 10.0,
      status: "Danger",
    },
    {
      locationName: "South Creek",
      currentLevel: 2.1,
      maxLevel: 5.0,
      status: "Safe",
    },
  ];

  // Alert data - important notifications
  const alerts = [
    {
      title: "High Water Level",
      message: "Central Dam water level is approaching maximum capacity.",
      type: "danger",
    },
    {
      title: "Heavy Rainfall Expected",
      message: "Weather forecast shows heavy rain in the next 6 hours.",
      type: "warning",
    },
  ];

  // ============================================
  // FUNCTIONS
  // ============================================

  // Toggle alerts visibility (Interactive Feature #2)
  const toggleAlerts = () => {
    setShowAlerts(!showAlerts);
  };

  // ============================================
  // RENDER / DISPLAY
  // ============================================

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ========== HEADER ========== */}
      <header className="bg-blue-600 text-white p-6 shadow-lg">
        <div className="container mx-auto">
          <h1 className="text-3xl">🌊 Flood Monitoring System</h1>
          <p className="text-blue-100 mt-1">
            Real-time water level monitoring and alerts
          </p>
        </div>
      </header>

      {/* ========== MAIN CONTENT ========== */}
      <main className="container mx-auto p-6 space-y-6">
        
        {/* Statistics Cards - Using GRID layout */}
        <section>
          <h2 className="text-xl mb-4">📊 Overview Statistics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {stats.map((stat, index) => (
              <StatsCard
                key={index}
                label={stat.label}
                value={stat.value}
                icon={stat.icon}
              />
            ))}
          </div>
        </section>

        {/* Water Levels - Using GRID layout */}
        <section>
          <h2 className="text-xl mb-4">💧 Water Levels by Location</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {waterLevels.map((location, index) => (
              <WaterLevelCard
                key={index}
                locationName={location.locationName}
                currentLevel={location.currentLevel}
                maxLevel={location.maxLevel}
                status={location.status}
              />
            ))}
          </div>
        </section>

        {/* Alerts Section - Using FLEXBOX layout */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">🚨 Active Alerts</h2>
            
            {/* Interactive Button - Toggle alerts visibility */}
            <Button onClick={toggleAlerts} variant="outline">
              {showAlerts ? "Hide Alerts" : "Show Alerts"}
            </Button>
          </div>

          {/* Show/hide alerts based on state (Interactive Feature) */}
          {showAlerts && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {alerts.map((alert, index) => (
                <AlertCard
                  key={index}
                  title={alert.title}
                  message={alert.message}
                  type={alert.type}
                />
              ))}
            </div>
          )}
        </section>

        {/* Instructions Section */}
        <section className="bg-white p-6 rounded-lg border">
          <h3 className="font-medium mb-2">ℹ️ How to Use This System</h3>
          <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
            <li>Check water levels at different locations</li>
            <li>Monitor active alerts for dangerous situations</li>
            <li>Green = Safe, Yellow = Warning, Red = Danger</li>
            <li>Click "Hide/Show Alerts" button to toggle alert visibility</li>
          </ul>
        </section>
      </main>

      {/* ========== FOOTER ========== */}
      <footer className="bg-gray-800 text-white p-4 mt-8">
        <div className="container mx-auto text-center text-sm">
          <p>Flood Monitoring System - Laboratory Activity #3</p>
          <p className="text-gray-400 mt-1">Built with React + TypeScript</p>
        </div>
      </footer>
    </div>
  );
}
